#ifndef MpcCtrl_H
#define MpcCtrl_H
#include <memory>
#include "common/mathTypes.h"
#include "thirdParty/quadProgpp/QuadProg++.hh"
#include "common/unitreeRobot.h"
#include "qpOASES.hpp"


class MpcCtrl{
public:
    MpcCtrl(double mass, Mat3 Ib, Mat6 S, double alpha);
    MpcCtrl(QuadrupedRobot *robModel);
    // Vec34 calF(RotMat rotM, Vec34 feetPos2B, VecInt4 contact,Vec12 dstate,Vec12 rstate,Eigen::MatrixXi& table);
    Vec34 calF(RotMat rotM, Vec34 feetPos2B, VecInt4 contact,Vec12 dstate,Vec12 rstate,Eigen::MatrixXi& table, Vec3 F_b, Vec3 pay_d);
    double getDtMpc(){return _dtMpc;}
    int getHorizonLength(){return _horizonLength;}
    bool IsNeedMpc(){return _iterationsNum % _iterationsBetweenMPC==0;}

private:
  // void calcTraj(Vec12 dstate);
    // void calMatrixA(Vec34 feetPos2B, RotMat rotM, VecInt4 contact);
    // void calVectorBd(Vec3 ddPcd, Vec3 dWbd, RotMat rotM);
    void calMatrixA(Vec34 feetPos2B, RotMat rotM, VecInt4 contact, Vec3 F_b);
    void calConstraints(Eigen::MatrixXi& table);
    void solveQP();
    void resize_qp_mats(int horizon);
    void calcTraj(Vec12 dstate, Vec3 pay_d, Vec3 F_b);

    // std::shared_ptr<Visualizer> Visualizer_Ptr_;

    Mat3 _Ib;
    Vec6 _bd;
    Vec3 _g;
    Vec3 _pcb;
    Vec12 _F;
    double _mass, _alpha, _fricRatio;

    //osqp
    Eigen::VectorXd _ub,_lb;
    Eigen::MatrixXd _fMat;
    qpOASES::real_t* H_qpoases;
    qpOASES::real_t *g_qpoases;
    qpOASES::real_t *A_qpoases;
    qpOASES::real_t *lb_qpoases;
    qpOASES::real_t *ub_qpoases;
    qpOASES::real_t *q_soln;

    qpOASES::real_t *H_red;
    qpOASES::real_t *g_red;
    qpOASES::real_t *A_red;
    qpOASES::real_t *lb_red;
    qpOASES::real_t *ub_red;
    qpOASES::real_t *q_red;
    char var_elim[2000];
    char con_elim[2000];


    //mpc
    int _iterationsNum; 
    int _iterationsBetweenMPC;
    double _dt;
    double _dtMpc;
    double _Fmax;
    int _horizonLength;
    Vec12 _weight;
    Eigen::VectorXd _Xd;
    Eigen::Matrix<double,19,1> _x_0;
    Eigen::VectorXd _traj;
    Eigen::Matrix<double, 19 , 19> _A;
    Eigen::Matrix<double,19,12> _B;
    Eigen::MatrixXd _Aqp;
    Eigen::MatrixXd _Bqp;
    Eigen::MatrixXd _S;
    Eigen::MatrixXd _qH;
    Eigen::VectorXd _qg;
    Eigen::MatrixXd _eye_12h;

};

#endif /* MpcCtrl_H*/