/**********************************************************************
 Copyright (c) 2020-2023, Unitree Robotics.Co.Ltd. All rights reserved.
***********************************************************************/
#ifndef MPC_CTRL_H
#define MPC_CTRL_H

#include "FSM/FSMState.h"
#include "Gait/GaitGenerator.h"
#include "control/MpcCtrl.h"

class State_MpcCtrl : public FSMState{
public:
    State_MpcCtrl(CtrlComponents *ctrlComp);
    ~State_MpcCtrl();
    void enter();
    void run();
    void exit();
    virtual FSMStateName checkChange();
    void setHighCmd(double vx, double vy, double wz);
private:
    void calcTau();
    void calcQQd();
    void calcCmd();
    virtual void getUserCmd();
    void calcBalanceKp();
    bool checkStepOrNot();
    //void calcTraj(Vec12 dstate,Vec12 rstate);

    GaitGenerator *_gait;
    Estimator *_est;
    QuadrupedRobot *_robModel;
    MpcCtrl *_mpcCtrl;
    WaveGenerator *_waveGenerator;
    //发布消息
    Pub *_pub;

    // Rob State
    Vec3  _posBody, _velBody;
    double _yaw, _dYaw;
    Vec34 _posFeetGlobal, _velFeetGlobal;
    Vec34 _posFeet2BGlobal;
    RotMat _B2G_RotMat, _G2B_RotMat;
    Vec12 _q;

    // Robot command
    Vec3 _pcd;
    Vec3 _vCmdGlobal, _vCmdBody;
    double _yawCmd, _dYawCmd;
    double _dYawCmdPast;
    Vec3 _wCmdGlobal;
    Vec34 _posFeetGlobalGoal, _velFeetGlobalGoal;
    Vec34 _posFeet2BGoal, _velFeet2BGoal;
    RotMat _Rd;
    Vec3 _ddPcd, _dWbd;
    Vec34 _forceFeetGlobal, _forceFeetBody;
    Vec34 _qGoal, _qdGoal;
    Vec12 _tau;

    // Control Parameters
    double _gaitHeight;
    Vec3 _posError, _velError;
    Mat3 _Kpp, _Kdp, _Kdw;
    double _kpw;
    Mat3 _KpSwing, _KdSwing;
    Vec2 _vxLim, _vyLim, _wyawLim;
    std::shared_ptr<Vec4> _phase;
    std::shared_ptr<VecInt4> _contact;

    double _lamda;
    double _mb,_d_mb;//估计的负载质量
    Vec3 _S_Compound;
    Vec3 _Loading;//估计的负载
    double _Gammam;
    Vec3 _Ym;
    Mat3 _KD;

    int count = 0;
    Mat3 _lamdaTu;
    Vec3 _S_CompoundTu;
    Mat3 _GammaTu;
    Vec3 _YmTu;
    Mat3 _KDTu;
    Vec3 _Tu;//估计的负载转矩
    Vec3 _Tb;
    Vec3 _kexi;
    Vec3 _dkexi;
    Vec3 _U;
    Mat3 _E;

    // slope 
    //当前足端位置
    Vec34 _Pi;
    //倾角；
    double _SlopeAngle;
    //第一次运行标志位
    bool _firstRun;
    Eigen::Matrix<double, 4 , 3 > _YM;
    Eigen::Matrix<double, 4 , 1 > _ZM;
    Vec3 _Angle;

    int count_num = 0;
    // Calculate average value
    std::shared_ptr<AvgCov> _avg_posError = std::make_shared<AvgCov>(3, "_posError", true, 1000, 1000, 1);
    std::shared_ptr<AvgCov> _avg_angError = std::make_shared<AvgCov>(3, "_angError", true, 1000, 1000, 1000);
};

#endif  // MPC_CTRL_H