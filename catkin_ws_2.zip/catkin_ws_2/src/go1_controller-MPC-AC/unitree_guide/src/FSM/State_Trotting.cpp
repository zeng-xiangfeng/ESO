/**********************************************************************
 Copyright (c) 2020-2023, Unitree Robotics.Co.Ltd. All rights reserved.
***********************************************************************/
#include "FSM/State_Trotting.h"
#include <iomanip>

State_Trotting::State_Trotting(CtrlComponents *ctrlComp)
             :FSMState(ctrlComp, FSMStateName::TROTTING, "trotting"), 
              _est(ctrlComp->estimator), _phase(ctrlComp->phase), 
              _contact(ctrlComp->contact), _robModel(ctrlComp->robotModel), 
              _balCtrl(ctrlComp->balCtrl),_pub(ctrlComp->pub){
    _gait = new GaitGenerator(ctrlComp);

    _gaitHeight = 0.08;

#ifdef ROBOT_TYPE_Go1
    _Kpp = Vec3(70, 70, 70).asDiagonal();
    _Kdp = Vec3(10, 10, 10).asDiagonal();
    _kpw = 780; 
    _Kdw = Vec3(70, 70, 70).asDiagonal();
    _KpSwing = Vec3(400, 400, 400).asDiagonal();
    _KdSwing = Vec3(10, 10, 10).asDiagonal();
#endif

#ifdef ROBOT_TYPE_A1
    _Kpp = Vec3(20, 20, 100).asDiagonal();
    _Kdp = Vec3(20, 20, 20).asDiagonal();
    _kpw = 400;
    _Kdw = Vec3(50, 50, 50).asDiagonal();
    _KpSwing = Vec3(400, 400, 400).asDiagonal();
    _KdSwing = Vec3(10, 10, 10).asDiagonal();
#endif

    _vxLim = _robModel->getRobVelLimitX();
    _vyLim = _robModel->getRobVelLimitY();
    _wyawLim = _robModel->getRobVelLimitYaw();



  //仿真
   
    _bandwidth_v=Vec3(0.5,0.5,1.5).asDiagonal();    //可以调节获取_Extend_V值的速度，当给x期望速度时，y也有期望速度出现，可以调y方向的_bandwidth_v
    _Kv=Vec3(0.215,0.15,0.25).asDiagonal();  //超调，来回移动,往大是超调
    _Kp=Vec3(5.8,5.8,10).asDiagonal();  //超调，来回移动,往大是超调
   
 
   _z<<0,0,1;
   __Ib=_robModel->getRobInertial();
   _Kq=Vec3(5,10,0.5).asDiagonal();    //固定时来回旋转
   _Kb=Vec3(-30,-35,-25.5).asDiagonal();  //固定后继续旋转一定的角度
   _Kw=Vec3(-5,-5,0.238).asDiagonal();  //固定后继续旋转一定的角度
   _bandwidth_w=Vec3(0.2,0.2,0.2).asDiagonal();




}

State_Trotting::~State_Trotting(){
    delete _gait;
}

void State_Trotting::enter(){
    _pcd = _est->getPosition();
    _pcd(2) = -_robModel->getFeetPosIdeal()(2, 0);
    _vCmdBody.setZero();
    _yawCmd = _lowState->getYaw();
    _Rd = rotz(_yawCmd);
    _wCmdGlobal.setZero();

    _ctrlComp->ioInter->zeroCmdPanel();
    _gait->restart();

    _Extend_V.setZero();
    _d_Extend_V.setZero();
    _p.setZero();
    _d_p.setZero();
    _v.setZero();
    _d_v.setZero();
    _u_v.setZero();
    _v_r.setZero();
    _d_v_r.setZero();
    _r_v.setZero();
    _d_pcd.setZero();
    _old_pcd.setZero();
    _Ee.setZero();
    _old_v_r.setZero();

    _Extend_W.setZero();
    _w_d.setZero();
    _b_v.setZero();
    _R_error_R_error_T.setZero();
    _w_r.setZero();
    _r_w.setZero();
    _w.setZero();
    _old_w_r.setZero();
    _w_r_d.setZero();
    _u_w.setZero();
    _d_Extend_W.setZero();
    _w_estimate.setZero();
    _d_w_estimate.setZero();
    _R_error.setZero();

}

void State_Trotting::exit(){
    _ctrlComp->ioInter->zeroCmdPanel();
    _ctrlComp->setAllSwing();
}

FSMStateName State_Trotting::checkChange(){
    if(_lowState->userCmd == UserCommand::L2_B){
        return FSMStateName::PASSIVE;
    }
    else if(_lowState->userCmd == UserCommand::L2_A){
        return FSMStateName::FIXEDSTAND;
    }
    else{
        return FSMStateName::TROTTING;
    }
}

void State_Trotting::run(){
    _posBody = _est->getPosition();
    _velBody = _est->getVelocity();
    _posFeet2BGlobal = _est->getPosFeet2BGlobal();
    _posFeetGlobal = _est->getFeetPos();
    _velFeetGlobal = _est->getFeetVel();
    _B2G_RotMat = _lowState->getRotMat();
    _G2B_RotMat = _B2G_RotMat.transpose();
    _yaw = _lowState->getYaw();
    _dYaw = _lowState->getDYaw();

    _userValue = _lowState->userValue;

    getUserCmd();
    calcCmd();

    _gait->setGait(_vCmdGlobal.segment(0,2), _wCmdGlobal(2), _gaitHeight);
    _gait->run(_posFeetGlobalGoal, _velFeetGlobalGoal);

    calcTau();
    calcQQd();

    if(checkStepOrNot()){
        _ctrlComp->setStartWave();
    }else{
        _ctrlComp->setAllStance();
    }

    _lowCmd->setTau(_tau);
    _lowCmd->setQ(vec34ToVec12(_qGoal));
    _lowCmd->setQd(vec34ToVec12(_qdGoal));

    for(int i(0); i<4; ++i){
        if((*_contact)(i) == 0){
            _lowCmd->setSwingGain(i);
        }else{
            _lowCmd->setStableGain(i);
        }
    }

}

bool State_Trotting::checkStepOrNot(){
    if( (fabs(_vCmdBody(0)) > 0.03) ||
        (fabs(_vCmdBody(1)) > 0.03) ||
        (fabs(_posError(0)) > 0.08) ||
        (fabs(_posError(1)) > 0.08) ||
        (fabs(_velError(0)) > 0.05) ||
        (fabs(_velError(1)) > 0.05) ||
        (fabs(_dYawCmd) > 0.20) ){
        return true;
    }else{
        return false;
    }
}

void State_Trotting::setHighCmd(double vx, double vy, double wz){
    _vCmdBody(0) = vx;
    _vCmdBody(1) = vy;
    _vCmdBody(2) = 0; 
    _dYawCmd = wz;
}

void State_Trotting::getUserCmd(){
    /* Movement */
    _vCmdBody(0) =  invNormalize(_userValue.ly, _vxLim(0), _vxLim(1));
    _vCmdBody(1) = -invNormalize(_userValue.lx, _vyLim(0), _vyLim(1));
    _vCmdBody(2) = 0;

    /* Turning */
    _dYawCmd = -invNormalize(_userValue.rx, _wyawLim(0), _wyawLim(1));
    _dYawCmd = 0.9*_dYawCmdPast + (1-0.9) * _dYawCmd;
    _dYawCmdPast = _dYawCmd;
}

void State_Trotting::calcCmd(){
    /* Movement */
    _vCmdGlobal = _B2G_RotMat * _vCmdBody;

    // std::cout<<"_B2G_RotMat ="<<_B2G_RotMat<<std::endl;

    _vCmdGlobal(0) = saturation(_vCmdGlobal(0), Vec2(_velBody(0)-0.2, _velBody(0)+0.2));
    _vCmdGlobal(1) = saturation(_vCmdGlobal(1), Vec2(_velBody(1)-0.2, _velBody(1)+0.2));

    _pcd(0) = saturation(_pcd(0) + _vCmdGlobal(0) * _ctrlComp->dt, Vec2(_posBody(0) - 0.05, _posBody(0) + 0.05));
    _pcd(1) = saturation(_pcd(1) + _vCmdGlobal(1) * _ctrlComp->dt, Vec2(_posBody(1) - 0.05, _posBody(1) + 0.05));

    _vCmdGlobal(2) = 0;

    /* Turning */
    _yawCmd = _yawCmd + _dYawCmd * _ctrlComp->dt;

    _Rd = rotz(_yawCmd);
    _wCmdGlobal(2) = _dYawCmd;
}

void State_Trotting::calcTau(){
    _posError = _pcd - _posBody;
    _velError = _vCmdGlobal - _velBody;

    std::cout<<"_posBody =  "<< _posBody.transpose()<<std::endl;
    std::cout<<"_pcd     =  "<< _pcd.transpose()<<std::endl;
    std::cout<<"_velBody   =  "<< _velBody.transpose()<<std::endl;
    std::cout<<"_vCmdGlobal   =  "<< _vCmdGlobal.transpose()<<std::endl;
    std::cout<<"_r_v = " <<_r_v.transpose()<<std::endl;
    std::cout<<"_v_r = "<<_v_r.transpose()<<std::endl;
    std::cout<<"_d_v_r = "<<_d_v_r.transpose()<<std::endl;
    

    // _ddPcd= _Kpp * _posError + _Kdp * _velError;
  
    //平动
    _Ee=_Ee+_posError*_ctrlComp->dt;

    // _d_pcd=(_pcd-_old_pcd)*(1/_ctrlComp->dt);
    // _old_pcd=_pcd;
     _d_pcd=_vCmdGlobal;

    _v_r=_d_pcd-_Kp*_posError*2-_Kp*_Kp*_Ee;

    _d_v_r=(_v_r-_old_v_r)*(1/_ctrlComp->dt);
    _old_v_r=_v_r;

    _r_v=_velBody-_v_r;

    _ddPcd = _Kv*_r_v-_d_v_r+_Extend_V;
    std::cout<<"_ddPcd  =  "<<_ddPcd.transpose() <<std::endl;

    //转动
    _w_d<<(_G2B_RotMat*skew(_z)*_Rd)(2,1),(_G2B_RotMat*skew(_z)*_Rd)(0,2),(_G2B_RotMat*skew(_z)*_Rd)(1,0); //式35
    _w_d<<0,0,_dYawCmd;
    _R_error=_Rd*_B2G_RotMat.transpose();
    _b_0=0.5*sqrt(1+_R_error(0,0)+_R_error(1,1)+_R_error(2,2));
    _R_error_R_error_T<<(_R_error-_R_error.transpose())(2,1),(_R_error-_R_error.transpose())(0,2),(_R_error-_R_error.transpose())(1,0);
    _b_v=1/(4*_b_0)*_R_error_R_error_T;  //式36
    _w_r=_R_error.transpose()*_w_d-_Kq*_b_v*2;  //式40
    _w(2)=_dYaw;  //实时角速度
    _r_w=_w-_w_r;
    _w_r_d=(_w_r-_old_w_r)*(1/_ctrlComp->dt);  //式43
    _old_w_r=_w_r;
    _M=_B2G_RotMat*__Ib*_B2G_RotMat.transpose();
    // _dWbd=(_w_r_d-_Extend_W-_Kw*_M.inverse()*_r_w-_Kb*_M.inverse()*_b_v);
   
    // _u_w=(_w_r_d-_Extend_W-_Kw*_M.inverse()*_r_w-_Kb*_M.inverse()*_b_v);
    // _dWbd=_M*_u_w;  //_dwbd代表式45中的t
    
    _dWbd  = _kpw*rotMatToExp(_Rd*_G2B_RotMat) + _Kdw * (_wCmdGlobal - _lowState->getGyroGlobal());

  

    _ddPcd(0) = saturation(_ddPcd(0), Vec2(-3, 3));
    _ddPcd(1) = saturation(_ddPcd(1), Vec2(-3, 3));
    _ddPcd(2) = saturation(_ddPcd(2), Vec2(-15, 15));

    _dWbd(0) = saturation(_dWbd(0), Vec2(-40, 40));
    _dWbd(1) = saturation(_dWbd(1), Vec2(-40, 40));
    _dWbd(2) = saturation(_dWbd(2), Vec2(-10, 10));
    

    _Extend_V_W();

    _forceFeetGlobal = - _balCtrl->calF(_ddPcd, _dWbd, _B2G_RotMat, _posFeet2BGlobal, *_contact);

    for(int i(0); i<4; ++i){
        if((*_contact)(i) == 0){
            _forceFeetGlobal.col(i) = _KpSwing*(_posFeetGlobalGoal.col(i) - _posFeetGlobal.col(i)) + _KdSwing*(_velFeetGlobalGoal.col(i)-_velFeetGlobal.col(i));
        }
    }

    _forceFeetBody = _G2B_RotMat * _forceFeetGlobal;
    _q = vec34ToVec12(_lowState->getQ());
    _tau = _robModel->getTau(_q, _forceFeetBody);

    double mm = 0;
    Vec12 q;
    q = vec34ToVec12(_forceFeetGlobal);
    for (int i = 0; i < 12; i++)
    {   
        // std::cout<<"Footforce["<<i<<"]="<<q[i]<<std::endl;
        if((i+1)%3==0)
        {
            mm += -q[i];
        }
    } 

    if (count%5 == 0)
    {
        _pub->pub_data_movement(_posBody, _pcd, _velBody, _vCmdGlobal, _lowState->getAccGlobal(), _ddPcd, mm, 0, _posError, _velError);
        _pub->pub_data_turning(rotMatToRPY(_B2G_RotMat),rotMatToRPY(_Rd),_lowState->getGyroGlobal(),_wCmdGlobal,_dWbd,Vec3().setZero(),Vec3().setZero(),rotMatToExp(_Rd*_G2B_RotMat),_wCmdGlobal - _lowState->getGyroGlobal());
        _pub->pub_data_leg(_tau);

        FILE *input1;
        input1 = fopen("Balance.txt","a");
        fprintf(input1,"%f %f %f\n",_posBody(2), _velBody(0), _lowState->getGyroGlobal()(2));//"机身高度","机身速度x","角速度"
        fclose(input1);
    }

    count++ ; 
}

void State_Trotting::calcQQd(){

    Vec34 _posFeet2B;
    _posFeet2B = _robModel->getFeet2BPositions(*_lowState,FrameType::BODY);
    
    for(int i(0); i<4; ++i){
        _posFeet2BGoal.col(i) = _G2B_RotMat * (_posFeetGlobalGoal.col(i) - _posBody);
        _velFeet2BGoal.col(i) = _G2B_RotMat * (_velFeetGlobalGoal.col(i) - _velBody); 
        // _velFeet2BGoal.col(i) = _G2B_RotMat * (_velFeetGlobalGoal.col(i) - _velBody - _B2G_RotMat * (skew(_lowState->getGyro()) * _posFeet2B.col(i)) );  //  c.f formula (6.12) 
    }
    
    _qGoal = vec12ToVec34(_robModel->getQ(_posFeet2BGoal, FrameType::BODY));
    _qdGoal = vec12ToVec34(_robModel->getQd(_posFeet2B, _velFeet2BGoal, FrameType::BODY));
}

void State_Trotting::_Extend_V_W(){

    //位置
    _d_Extend_V=_bandwidth_v*_bandwidth_v*_bandwidth_v*(_posBody-_p);
    _Extend_V=_Extend_V+_d_Extend_V*_ctrlComp->dt;
    
    _d_v=-_ddPcd+_Extend_V+Vec3(3,3,3).asDiagonal()*_bandwidth_v*_bandwidth_v*(_posBody-_p);
    _v=_v+_d_v*_ctrlComp->dt;

    _d_p=_v + Vec3(3,3,3).asDiagonal()*_bandwidth_v*(_posBody-_p);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
    _p=_p+_d_p*_ctrlComp->dt;                                                                                                                                 

    //姿态
    _d_Extend_W=_bandwidth_w*_bandwidth_w*(_w-_w_estimate);
    _Extend_W=_Extend_W+_d_Extend_W*_ctrlComp->dt;
    _d_w_estimate=_u_w+_Extend_W+_bandwidth_w*(_w-_w_estimate)*2;
    _w_estimate=_w_estimate+_d_w_estimate*_ctrlComp->dt;
    std::cout<<"_Extend_V =  "<<_Extend_V.transpose()<<std::endl;
} 
