/**********************************************************************
 Copyright (c) 2020-2023, Unitree Robotics.Co.Ltd. All rights reserved.
***********************************************************************/
#include "FSM/State_MpcCtrl.h"
#include <iomanip>

State_MpcCtrl::State_MpcCtrl(CtrlComponents *ctrlComp)
             :FSMState(ctrlComp, FSMStateName::MPCCTRL, "mpcCtrl"), 
              _est(ctrlComp->estimator), _phase(ctrlComp->phase), 
              _contact(ctrlComp->contact), _robModel(ctrlComp->robotModel), 
              _mpcCtrl(ctrlComp->mpcCtrl),_waveGenerator(ctrlComp->waveGen),
              _pub(ctrlComp->pub){
    _gait = new GaitGenerator(ctrlComp);

    _gaitHeight = 0.08;

#ifdef ROBOT_TYPE_Go1
    _Kpp = Vec3(70, 70, 70).asDiagonal();
    _Kdp = Vec3(10, 10, 10).asDiagonal();
    _kpw = 780; //780
    _Kdw = Vec3(70, 70, 70).asDiagonal();
    _KpSwing = Vec3(400, 400, 400).asDiagonal();
    _KdSwing = Vec3(10, 10, 10).asDiagonal();
#endif

#ifdef ROBOT_TYPE_A1
    _Kpp = Vec3(20, 20, 100).asDiagonal();
    _Kdp = Vec3(20, 20, 20).asDiagonal();
    _kpw = 400;
    _Kdw = Vec3(50, 50, 50).asDiagonal();
    _KpSwing = Vec3(400, 400, 400).asDiagonal();
    _KdSwing = Vec3(10, 10, 10).asDiagonal();
#endif

    _vxLim = _robModel->getRobVelLimitX();
    _vyLim = _robModel->getRobVelLimitY();
    _wyawLim = _robModel->getRobVelLimitYaw();

 //仿真参数
    _Gammam = 2;
    _lamda = 25;
    _KD = Vec3(0,0,0.01).asDiagonal();

    _KDTu = Vec3(1.5,1.5,0.5).asDiagonal();
    _lamdaTu = Vec3(25, 25, 5).asDiagonal();
    _GammaTu = Vec3(1.5, 1.5, 0.7).asDiagonal();

//实机参数
    // _lamda = 5;
    // _Gammam = 15;
    // _KD = Vec3(0,0,0.02).asDiagonal();
    
    // _KDTu = Vec3(1.5,1.5,0.5).asDiagonal();
    // _lamdaTu = Vec3(1, 1, 0.5).asDiagonal();
    // _GammaTu = Vec3(1.5, 1.5, 0.7).asDiagonal();


}

State_MpcCtrl::~State_MpcCtrl(){
    delete _gait;
}

void State_MpcCtrl::enter(){
    FILE *input1;
    input1 = fopen("/home/liwenzhi/workspace/unitree_mpc_ws/src/data/mpc_DOB.txt","w");
    fprintf(input1,"%s %s %s %s %s %s %s\n","负载质量","机身高度","期望机身高度","机身速度x","期望速度", "期望角速度", "角速度");
    fclose(input1);
    _pcd = _est->getPosition();
    _pcd(2) = -_robModel->getFeetPosIdeal()(2, 0);
    _vCmdBody.setZero();
    _yawCmd = _lowState->getYaw();
    _Rd = rotz(_yawCmd);
    _dYawCmdPast = 0;
    _wCmdGlobal.setZero();

    _ctrlComp->ioInter->zeroCmdPanel();
    _gait->restart();

    _d_mb = 0;
    _mb = 0;
    _Loading.setZero();

    _Tu.setZero();
    _E.setIdentity();
    _U.setZero();
    _kexi.setZero();

    _firstRun = true;
}

void State_MpcCtrl::exit(){
    _ctrlComp->ioInter->zeroCmdPanel();
    _ctrlComp->setAllSwing();
}

FSMStateName State_MpcCtrl::checkChange(){
    if(_lowState->userCmd == UserCommand::L2_B){
        return FSMStateName::PASSIVE;
    }
    else if(_lowState->userCmd == UserCommand::L2_A){
        return FSMStateName::FIXEDSTAND;
    }
    else{
        return FSMStateName::MPCCTRL;
    }
}

void State_MpcCtrl::run(){
    _posBody = _est->getPosition();
    _velBody = _est->getVelocity();
    _posFeet2BGlobal = _est->getPosFeet2BGlobal();
    _posFeetGlobal = _est->getFeetPos();
    _velFeetGlobal = _est->getFeetVel();
    _B2G_RotMat = _lowState->getRotMat();
    _G2B_RotMat = _B2G_RotMat.transpose();
    _yaw = _lowState->getYaw();
    _dYaw = _lowState->getDYaw();

    _userValue = _lowState->userValue;//这里可能要注释

    getUserCmd();
    calcCmd();

    _gait->setGait(_vCmdGlobal.segment(0,2), _wCmdGlobal(2), _gaitHeight);
    _gait->run(_posFeetGlobalGoal, _velFeetGlobalGoal);

    calcTau();
    calcQQd();

    if(checkStepOrNot()){
        _ctrlComp->setStartWave();
    }else{
        _ctrlComp->setAllStance();
    }

    _lowCmd->setTau(_tau);
    _lowCmd->setQ(vec34ToVec12(_qGoal));
    _lowCmd->setQd(vec34ToVec12(_qdGoal));

    for(int i(0); i<4; ++i){
        if((*_contact)(i) == 0){
            _lowCmd->setSwingGain(i);
        }else{
            _lowCmd->setStableGain(i);
        }
    }

}

bool State_MpcCtrl::checkStepOrNot(){
    if( (fabs(_vCmdBody(0)) > 0.03) ||
        (fabs(_vCmdBody(1)) > 0.03) ||
        (fabs(_posError(0)) > 0.08) ||
        (fabs(_posError(1)) > 0.08) ||
        (fabs(_velError(0)) > 0.05) ||
        (fabs(_velError(1)) > 0.05) ||
        (fabs(_dYawCmd) > 0.20) ){
        return true;
    }else{
        return false;
    }
}

void State_MpcCtrl::setHighCmd(double vx, double vy, double wz){
    _vCmdBody(0) = vx;
    _vCmdBody(1) = vy;
    _vCmdBody(2) = 0; 
    _dYawCmd = wz;
}

void State_MpcCtrl::getUserCmd(){
    /* Movement */
    // if (count_num<1500)
    // {
    //     _vCmdBody(0) = 0.002 * count_num / 3;
    // }
    // else{
    //     _vCmdBody(0) = 1.0;
    // }

    _vCmdBody(0) =  invNormalize(_userValue.ly, _vxLim(0), _vxLim(1));
    _vCmdBody(1) = -invNormalize(_userValue.lx, _vyLim(0), _vyLim(1));
    _vCmdBody(2) = 0;

    /* Turning */
    _dYawCmd = -invNormalize(_userValue.rx, _wyawLim(0), _wyawLim(1));
    _dYawCmd = 0.9*_dYawCmdPast + (1-0.9) * _dYawCmd;
    _dYawCmdPast = _dYawCmd;
}

void State_MpcCtrl::calcCmd(){
    /* Movement */
    _vCmdGlobal = _B2G_RotMat * _vCmdBody;

    _vCmdGlobal(0) = saturation(_vCmdGlobal(0), Vec2(_velBody(0)-0.2, _velBody(0)+0.2));
    _vCmdGlobal(1) = saturation(_vCmdGlobal(1), Vec2(_velBody(1)-0.2, _velBody(1)+0.2));

    _pcd(0) = saturation(_pcd(0) + _vCmdGlobal(0) * _ctrlComp->dt, Vec2(_posBody(0) - 0.05, _posBody(0) + 0.05));
    _pcd(1) = saturation(_pcd(1) + _vCmdGlobal(1) * _ctrlComp->dt, Vec2(_posBody(1) - 0.05, _posBody(1) + 0.05));

    _vCmdGlobal(2) = 0;

    /* Turning */
    if(fabs(_yaw - _yawCmd)>5.0)
    {
        _yawCmd = _yaw;
    }
    _yawCmd = _yawCmd + _dYawCmd * _ctrlComp->dt;
    //_Rd = rotz(_yawCmd)*roty(-_Angle(1));
    _Rd = rotz(_yawCmd);
    _wCmdGlobal(2) = _dYawCmd;
}

void State_MpcCtrl::calcTau(){
    _posError = _pcd - _posBody;
    _velError = _vCmdGlobal - _velBody;

    _ddPcd = _Kpp * _posError + _Kdp * _velError;
    _dWbd  = _kpw*rotMatToExp(_Rd*_G2B_RotMat) + _Kdw * (_wCmdGlobal - _lowState->getGyroGlobal());

    _ddPcd(0) = saturation(_ddPcd(0), Vec2(-3, 3));
    _ddPcd(1) = saturation(_ddPcd(1), Vec2(-3, 3));
    _ddPcd(2) = saturation(_ddPcd(2), Vec2(-5, 5));

    _dWbd(0) = saturation(_dWbd(0), Vec2(-40, 40));
    _dWbd(1) = saturation(_dWbd(1), Vec2(-40, 40));
    _dWbd(2) = saturation(_dWbd(2), Vec2(-10, 10));

    //MPC问题构建
    Vec12 rstate;
    Vec12 dstate;
    //Vec3 drpy = rotMatToRPY(_Rd);
    dstate<<0,0,_yawCmd,_pcd,_wCmdGlobal,_vCmdGlobal;
    Vec3 rrpy = rotMatToRPY(_B2G_RotMat);
    //rrpy(2) = saturation(rrpy(2), Vec2(_yawCmd - 0.05, _yawCmd + 0.05));
    rstate<<rrpy,_posBody,_lowState->getGyroGlobal(),_velBody;

    std::cout<<"wmd: "<<_wCmdGlobal.transpose()<<std::endl;

    int horizonLength = _mpcCtrl->getHorizonLength();
    Eigen::MatrixXi table;
    table.resize(4,horizonLength);
    table.setOnes();
    table.col(0) = *_contact;
    if (_mpcCtrl->IsNeedMpc())
    {
        double dt = _mpcCtrl->getDtMpc();
        for (int i = 1; i < horizonLength; i++)
        {
            double phasedt = dt * i;
            VecInt4 contact = *_contact;
            Vec4 phase = *_phase;
            _waveGenerator->calcWavebyPhase(phase, contact, _ctrlComp->getWaveStatus(), phasedt);
            table.col(i) = contact;
        }
    }

    Mat3 R_yaw = rotz(_yaw);

    //平动
    _S_Compound = -_velError - _lamda * _posError;
    _Ym = _ddPcd + _lamda * _velError + Vec3(0,0,9.81);
    _d_mb = -_Gammam * _Ym.transpose() * _S_Compound;
    _mb = _mb + _d_mb * _ctrlComp->dt;
    _Loading = _Ym * _mb - _KD *_S_Compound;

    //转动
    Vec3 _rotError = -rotMatToExp(_Rd*_G2B_RotMat);
    Vec3 _wError = _lowState->getGyroGlobal() - _wCmdGlobal;
    Mat3 _Ibody = Vec3(0.0792, 0.2085, 0.2265).asDiagonal(); 

    _S_CompoundTu = _wError + _lamdaTu * _rotError;
    _Tu = _GammaTu*_Ibody*_lowState->getGyroGlobal() + _kexi;//_Tu = d
    _dkexi = -_GammaTu*(_U + _Tu);
    _kexi = _kexi + _dkexi* _ctrlComp->dt;
    _U = -(_KDTu*_lamdaTu + _E)*_rotError-(_KDTu + _lamdaTu)*_wError-_Tu;

    // _forceFeetGlobal = - _mpcCtrl->calF(R_yaw, _posFeet2BGlobal, *_contact,dstate,rstate,table);
    _forceFeetGlobal = - _mpcCtrl->calF(R_yaw, _posFeet2BGlobal, *_contact,dstate,rstate,table, _Loading, _Tu);

    for(int i(0); i<4; ++i){
        if((*_contact)(i) == 0){
            _forceFeetGlobal.col(i) = _KpSwing*(_posFeetGlobalGoal.col(i) - _posFeetGlobal.col(i)) + _KdSwing*(_velFeetGlobalGoal.col(i)-_velFeetGlobal.col(i));
        }
    }

    _forceFeetBody = _G2B_RotMat * _forceFeetGlobal;
    _q = vec34ToVec12(_lowState->getQ());
    _tau = _robModel->getTau(_q, _forceFeetBody);
    std::cout<<"_tau = "<<_tau.transpose()<<std::endl;

    double mm = 0;
    Vec12 q;
    q = vec34ToVec12(_forceFeetGlobal);
    for (int i = 0; i < 12; i++)
    {   
        // std::cout<<"Footforce["<<i<<"]="<<q[i]<<std::endl;
        if((i+1)%3==0)
        {
            mm += -q[i];
        }
    }

    if (count_num%5 == 0)
    {
        _pub->pub_data_movement(_posBody, _pcd, _velBody, _vCmdGlobal, _lowState->getAccGlobal(), _ddPcd, mm, 0, _posError, _velError);
        _pub->pub_data_turning(rotMatToRPY(_B2G_RotMat),rotMatToRPY(_Rd),_lowState->getGyroGlobal(),_wCmdGlobal,_dWbd,Vec3().setZero(),Vec3().setZero(),rotMatToExp(_Rd*_G2B_RotMat),_wCmdGlobal - _lowState->getGyroGlobal());
        _pub->pub_data_leg(_tau);

        FILE *input1;
        input1 = fopen("/home/liwenzhi/workspace/unitree_mpc_ws/src/data/mpc_DOB.txt","a");
        fprintf(input1,"%f %f %f %f %f %f %f\n",_mb,_posBody(2),_pcd(2),_velBody(0),_vCmdGlobal(0),_dYawCmd,_lowState->getGyroGlobal()(2));
        //"负载质量","机身高度","期望机身高度","机身速度x","期望速度", "期望角速度", "角速度"
        fclose(input1);  
    }
    count_num++;
}

void State_MpcCtrl::calcQQd(){

    Vec34 _posFeet2B;
    _posFeet2B = _robModel->getFeet2BPositions(*_lowState,FrameType::BODY);
    
    for(int i(0); i<4; ++i){
        _posFeet2BGoal.col(i) = _G2B_RotMat * (_posFeetGlobalGoal.col(i) - _posBody);
        _velFeet2BGoal.col(i) = _G2B_RotMat * (_velFeetGlobalGoal.col(i) - _velBody); 
        // _velFeet2BGoal.col(i) = _G2B_RotMat * (_velFeetGlobalGoal.col(i) - _velBody - _B2G_RotMat * (skew(_lowState->getGyro()) * _posFeet2B.col(i)) );  //  c.f formula (6.12) 
    }
    
    _qGoal = vec12ToVec34(_robModel->getQ(_posFeet2BGoal, FrameType::BODY));
    _qdGoal = vec12ToVec34(_robModel->getQd(_posFeet2B, _velFeet2BGoal, FrameType::BODY));
}

