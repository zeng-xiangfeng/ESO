#include "control/pub.h"

Pub::Pub(){
    pub_mp = _nh.advertise<std_msgs::Float64>("/mp",1);
    pub_movement = _nh.advertise<unitree_guide::publish_movement>("/mdata_movement",20);
    pub_turning = _nh.advertise<unitree_guide::publish_turning>("/mdata_turning",20);
    pub_leg = _nh.advertise<unitree_guide::leg>("/mdata_leg",10);
    sub_param = _nh.subscribe("/data_config",100,&Pub::sub_data_param,this);
}

Pub::~Pub(){

}
// 发布估计负载质量
void Pub::pub_data_mp(double _mp){
    data_mp.data = _mp; 
    pub_mp.publish(data_mp);
    ros::spinOnce();
}
// 发布机身位置、速度、加速度、足端力之和等消息
void Pub::pub_data_movement(Vec3 p, Vec3 p_d, Vec3 v, Vec3 v_d, Vec3 a, Vec3 a_d, double sumfootforce, double d_mp, Vec3 err_p, Vec3 err_v){
    for (int i = 0; i < 3; i++)
    {
        data_movement.p[i]   = p[i];
        data_movement.p_d[i] = p_d[i];
        data_movement.err_p[i] = err_p[i];
        data_movement.v[i]   = v[i];
        data_movement.v_d[i] = v_d[i];
        data_movement.err_v[i] = err_v[i];
        data_movement.a[i]   = a[i];
        data_movement.a_d[i] = a_d[i];
    }
    data_movement.sumfootforce = sumfootforce;
    data_movement.d_mp = d_mp;
    pub_movement.publish(data_movement);
    ros::spinOnce();
}
// 发布机身方向、角速度、干扰项d、辅助变量更新律dkexi、转矩输出U
void Pub::pub_data_turning(Vec3 q, Vec3 q_d, Vec3 w, Vec3 w_d, Vec3 err_q, Vec3 err_w, Vec3 disturbance, Vec3 dkexi, Vec3 U){
    for (int i = 0; i < 3; i++)
    {
        data_turning.q[i]      = q[i];
        data_turning.q_d[i]    = q_d[i];
        data_turning.w[i]      = w[i];
        data_turning.w_d[i]    = w_d[i];
        data_turning.err_q[i]  = err_q[i];
        data_turning.err_w[i]  = err_w[i];
        data_turning.disturbance[i]   = disturbance[i];
        data_turning.dkexi[i]  = dkexi[i];
        data_turning.U[i] = U[i];
    }
    pub_turning.publish(data_turning);
    ros::spinOnce();
}
void Pub::pub_data_leg(Vec12 tau){
    for (int i = 0; i < 3; i++){

        data_leg.leg0[i] = tau[3*0+i];
        data_leg.leg1[i] = tau[3*1+i];
        data_leg.leg2[i] = tau[3*2+i];
        data_leg.leg3[i] = tau[3*3+i];       
    }
    pub_leg.publish(data_leg);
    ros::spinOnce();   
}
//订阅参数消息
void Pub::sub_data_param(const param_pkg::Dynamicparam & msg){

    data_param.Gammam = msg.Gammam;
    data_param.lamda = msg.lamda;
    data_param.KD = msg.KD;
    data_param.KDTu = msg.KDTu;
    data_param.GammamTu = msg.GammamTu;
    data_param.lamdaTu = msg.lamdaTu;
    // std::cout<<"***msg.Gammam*** = "<<msg.Gammam<<std::endl;
}
