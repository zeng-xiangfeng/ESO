#include "control/MpcCtrl.h"
#include "common/mathTools.h"
#include "common/timeMarker.h"
#include <eigen3/unsupported/Eigen/MatrixFunctions>
#include <chrono>
#define BIG_NUMBER 1e10


bool near_zero(double a)
{
  return (a < 0.01 && a > -.01) ;
}

bool near_one(double a)
{
  return near_zero(a-1);
}

void matrix_to_real(qpOASES::real_t* dst, Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> src, int rows, int cols)
{
  int a = 0;
  for(int r = 0; r < rows; r++)
  {
    for(int c = 0; c < cols; c++)
    {
      dst[a] = src(r,c);
      a++;
    }
  }
}







MpcCtrl::MpcCtrl(double mass, Mat3 Ib, Mat6 S, double alpha)
            : _mass(mass), _Ib(Ib), _S(S), _alpha(alpha){

    _g << 0, 0, -9.81;
    _fricRatio = 0.3;

}


////改////
MpcCtrl::MpcCtrl(QuadrupedRobot *robModel){
 

    _mass = robModel->getRobMass();
    _pcb = robModel->getPcb();
    _Ib = robModel->getRobInertial();
    _g << 0, 0, -9.81;

    _alpha = 1e-5;

    _fricRatio = 0.4;


    //mpc 
    _iterationsNum = 0;
    _iterationsBetweenMPC = 1;
    _horizonLength = 5;
    _dt = 0.002;
    _dtMpc = 10 * _dt*_iterationsBetweenMPC;
    _traj.resize(12*_horizonLength);

    _Aqp.resize(19*_horizonLength,19);
    _Bqp.resize(19*_horizonLength,12*_horizonLength);
    _S.resize(19*_horizonLength,19*_horizonLength);
    _Xd.resize(19*_horizonLength);
    _qH.resize(12*_horizonLength,12*_horizonLength);
    _qg.resize(12*_horizonLength);
    _eye_12h.resize(12*_horizonLength,12*_horizonLength);
    _eye_12h.setIdentity();


    _traj.setZero();
    _Aqp.setZero();
    _Bqp.setZero();
    _S.setZero();
    
    //_weight<<5, 5, 10, 30, 30, 50, 0.0, 0.0, 0.1, 0.2, 0.1, 0.1;
    //_weight<<1, 1, 5, 5, 5, 20, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1;
    // _weight<<1, 1, 5, 5, 5, 30, 0.0, 0.0, 0.2, 0.2, 0.2, 0.5; 
    // _weight<<1, 1, 5, 15, 15, 100, 0.0, 0.0, 0.2, 0.8, 1.0, 2; 
    _weight<<1, 1, 5, 15, 15, 100, 0.0, 0.0, 0.2, 0.2, 0.2, 2;
    _Xd.setZero();

    resize_qp_mats(_horizonLength);


    
}

void MpcCtrl::resize_qp_mats(int horizon)
{
    //ospq
    int h2 = horizon*horizon; 
    _ub.resize(20*_horizonLength);
    _lb.resize(20*_horizonLength);
    _fMat.resize(20*_horizonLength,12*_horizonLength);
    _ub.setZero();
    _lb.setZero();
    _Fmax = 500;

    H_qpoases = (qpOASES::real_t *)malloc(12 * 12 * horizon * horizon * sizeof(qpOASES::real_t));

    g_qpoases = (qpOASES::real_t *)malloc(12 * 1 * horizon * sizeof(qpOASES::real_t));

    A_qpoases = (qpOASES::real_t *)malloc(12 * 20 * horizon * horizon * sizeof(qpOASES::real_t));

    lb_qpoases = (qpOASES::real_t *)malloc(20 * 1 * horizon * sizeof(qpOASES::real_t));

    ub_qpoases = (qpOASES::real_t *)malloc(20 * 1 * horizon * sizeof(qpOASES::real_t));

    q_soln = (qpOASES::real_t *)malloc(12 * horizon * sizeof(qpOASES::real_t));

    H_red = (qpOASES::real_t *)malloc(12 * 12 * horizon * horizon * sizeof(qpOASES::real_t));

    g_red = (qpOASES::real_t *)malloc(12 * 1 * horizon * sizeof(qpOASES::real_t));

    A_red = (qpOASES::real_t *)malloc(12 * 20 * horizon * horizon * sizeof(qpOASES::real_t));

    lb_red = (qpOASES::real_t *)malloc(20 * 1 * horizon * sizeof(qpOASES::real_t));

    ub_red = (qpOASES::real_t *)malloc(20 * 1 * horizon * sizeof(qpOASES::real_t));

    q_red = (qpOASES::real_t *)malloc(12 * horizon * sizeof(qpOASES::real_t));
}


////改////
void MpcCtrl::calcTraj(Vec12 dstate, Vec3 pay_d, Vec3 F_b)
{
    //xd
    _Xd.setZero();
    _traj.setZero();
    for(int i = 0; i<_horizonLength;i++)
    {
        if(i==0)
        {
            _traj.segment(0,12) = dstate;
            // Eigen::Matrix<double,13,1> xd;
            // xd<<dstate,-9.8f;
            // _Xd.segment(0,13) = xd;

            Eigen::Matrix<double,19,1> xd;
            // F_b[2] = F_b[2] + 9.8f;
            xd << dstate, pay_d, -F_b, -9.8f;
            _Xd.segment(0,19) = xd;

            // Eigen::Matrix<double,16,1> xd;
            // xd << dstate, -9.8f, pay_d;
            // _Xd.segment(0,16) = xd;
        }
        else
        {
            Vec12 state_i = _traj.segment(12*(i-1),12);
            state_i(4) += state_i(10)*_dtMpc;
            state_i(5) += state_i(11)*_dtMpc;
            state_i(3) += state_i(9)*_dtMpc;
            _traj.segment(12*i,12) = state_i;
            // Eigen::Matrix<double,13,1> xd;
            // xd<<state_i,-9.8;
            // _Xd.segment(13*i,13) = xd;

            Eigen::Matrix<double,19,1> xd;
            // F_b[2] = F_b[2] + 9.8f;
            xd<<state_i, pay_d, -F_b, -9.8f;
            _Xd.segment(19*i,19) = xd;

            // Eigen::Matrix<double,16,1> xd;
            // xd<<state_i, -9.8f, pay_d;
            // _Xd.segment(16*i,16) = xd;
            

        }
    }


}
//dstate<<drpy,_pcd,_wCmdGlobal,_vCmdGlobal;

////改////
Vec34 MpcCtrl::calF(RotMat rotM, Vec34 feetPos2B, VecInt4 contact,Vec12 dstate,Vec12 rstate,Eigen::MatrixXi& table, Vec3 F_b, Vec3 pay_d){

    if ((_iterationsNum % _iterationsBetweenMPC) == 0)
    {
        auto begin = std::chrono::steady_clock::now();

        _x_0 << rstate, pay_d, -F_b, -9.8f;//改   不算13x1吗 为什么能装19维
 
        calcTraj(dstate, pay_d, F_b);
        calMatrixA(feetPos2B, rotM, contact, F_b);
        calConstraints(table);

        _qH = 2 * (_Bqp.transpose() * _S * _Bqp + _alpha * _eye_12h);
        _qg = 2 * _Bqp.transpose() * _S * (_Aqp * _x_0 - _Xd);

        solveQP();
 
        auto end1 = std::chrono::steady_clock::now();
        auto timeInterval1 = std::chrono::duration_cast<std::chrono::milliseconds>(end1-begin);
        //std::cout << "Running Time1: " << timeInterval1.count()  << "ms" << std::endl;
    }
    _iterationsNum++;
    // std::cout<<"机器人足端力:"<<_F.transpose()<<std::endl;
    return vec12ToVec34(_F);
}



////改////
void MpcCtrl::calMatrixA(Vec34 feetPos2B, RotMat rotM, VecInt4 contact, Vec3 F_b){   
    //xdot = Ax + Bu

     Mat3 I_w = rotM * _Ib * rotM.transpose();
 #undef inverse
    Mat3 I_w_inverse = I_w.inverse();
 #define inverse lu_inverse
    // A
    _A.setZero();
    _A.block(0,6,3,3) = rotM.transpose();//旋转矩阵转置
    _A.block(3,9,3,3) = Eigen::Matrix3d::Identity();
    // _A(11,12) = 1.f;
    // _A.block(6,13,3,3) = I_w_inverse;
    _A.block(6,12,3,3) = I_w_inverse;
    _A.block(9,15,3,3) = Eigen::Matrix3d::Identity()/ _mass;
    _A(11,18) = 1.f;
    // B
   
    _B.setZero();
   
    for(int i=0;i<4;i++){
        _B.block(6,3*i,3,3) = I_w_inverse*skew(feetPos2B.col(i));
        _B.block(9,3*i,3,3) = (1/_mass)*Eigen::Matrix3d::Identity();
    }
    


    Eigen::Matrix<double,31,31> ABc,expmm;//改
    Eigen::Matrix<double,19,19> Adt;//改
    Eigen::Matrix<double,19,12> Bdt;//改
    ABc.setZero();
    ABc.block(0,0,19,19) = _A;//改
    ABc.block(0,19,19,12) = _B;//改
    ABc = _dtMpc*ABc;
    expmm = ABc.exp();
   
    Adt = expmm.block(0,0,19,19);//改
    // // Adt(5,18) = 0;
    Bdt = expmm.block(0,19,19,12);//改
   

    Eigen::Matrix<double,19,19> powerMats[20];
     powerMats[0].setIdentity();
    for(int i = 1; i < _horizonLength; i++) {
        powerMats[i] = Adt * powerMats[i-1];
    }
    // for(int i = 0; i<_horizonLength;i++)
    // {
    //     _Aqp.block(19*i,0,19,19) = powerMats[i+1];
    //     // std::cout << "_Aqp: " << _Aqp<< std::endl;
    //     // _Aqp.block(19*i,0,19,19) = powerMats[i];
    //     for(int j=0;j<_horizonLength;j++)
    //     {
    //         if(i>=j)
    //         {
    //             int a_num = i - j;
    //             _Bqp.block(19*i,12*j,19,12) =powerMats[a_num] * Bdt;
    //         }
    //         std::cout << "_Bqp: " << _Bqp<< std::endl;
    //     }    
        
    // }
  
    for(int i = 0; i<_horizonLength;i++)
    {
        // _Aqp.block(19*i,0,19,19) = powerMats[i+1];
        // std::cout << "_Aqp: " << _Aqp<< std::endl;
        _Aqp.block(19*i,0,19,19) = powerMats[i];
        for(int j=0;j<_horizonLength;j++)
        {
            if (i == 0)
            {
                 _Bqp.block(19*i,12*j,19,12) =Eigen::MatrixXd::Zero(19,12);
            }
            else{
                if(i>j)
            {
                int a_num = i - j - 1;
                _Bqp.block(19*i,12*j,19,12) =powerMats[a_num] * Bdt;
            }
            }
            
            // std::cout << "_Bqp: " << _Bqp<< std::endl;
        }    
        
    }

    // S
    // Eigen::Matrix<double,13,1> full_weight;
    // Eigen::Matrix<double,18,1> full_weight;
    Eigen::Matrix<double,19,1> full_weight;
    // full_weight<<_weight, 5.0, 5.0, 15.0, 8.0, 2.0, 15.0, 0.0;
    full_weight<<_weight, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0;
    _S.diagonal() = full_weight.replicate(_horizonLength,1);
   

}



void MpcCtrl::calConstraints(Eigen::MatrixXi& table){
    int k=0;
    _ub.setZero();
    _fMat.setZero();
    for(int i=0;i<_horizonLength;i++)
    {
        for(int j=0;j<4;j++)
        {
            _ub(5*k+0) = BIG_NUMBER;
            _ub(5*k+1) = BIG_NUMBER;
            _ub(5*k+2) = BIG_NUMBER;
            _ub(5*k+3) = BIG_NUMBER;
            _ub(5*k+4) = _Fmax*table(j,i);
            k++;
        }
    }

    double mu = 1.f / _fricRatio;
    Eigen::Matrix<double, 5, 3> f_block;

    f_block << mu, 0, 1.f,
        -mu, 0, 1.f,
        0, mu, 1.f,
        0, -mu, 1.f,
        0, 0, 1.f;

    for (int i = 0; i < _horizonLength * 4; i++)
    {
        _fMat.block(i * 5, i * 3, 5, 3) = f_block;
    }
}




void MpcCtrl::solveQP()
{
    matrix_to_real(H_qpoases, _qH, _horizonLength * 12, _horizonLength * 12);
    matrix_to_real(g_qpoases, _qg, _horizonLength * 12, 1);
    matrix_to_real(A_qpoases, _fMat, _horizonLength * 20, _horizonLength * 12);
    matrix_to_real(ub_qpoases, _ub, _horizonLength * 20, 1);

    for (int i = 0; i < 20 * _horizonLength; i++)
        lb_qpoases[i] = 0.0f;

    int num_constraints = 20 * _horizonLength;
    int num_variables = 12 * _horizonLength;

    qpOASES::int_t nWSR = 100;

    int new_vars = num_variables;
    int new_cons = num_constraints;

    for (int i = 0; i < num_constraints; i++)
        con_elim[i] = 0;

    for (int i = 0; i < num_variables; i++)
        var_elim[i] = 0;

    for (int i = 0; i < num_constraints; i++)
    {
        if (!(near_zero(lb_qpoases[i]) && near_zero(ub_qpoases[i])))
            continue;
        double *c_row = &A_qpoases[i * num_variables];
        for (int j = 0; j < num_variables; j++)
        {
            if (near_one(c_row[j]))
            {
                new_vars -= 3;
                new_cons -= 5;
                int cs = (j * 5) / 3 - 3;
                var_elim[j - 2] = 1;
                var_elim[j - 1] = 1;
                var_elim[j] = 1;
                con_elim[cs] = 1;
                con_elim[cs + 1] = 1;
                con_elim[cs + 2] = 1;
                con_elim[cs + 3] = 1;
                con_elim[cs + 4] = 1;
            }
        }
    }

    int var_ind[new_vars];
    int con_ind[new_cons];
    int vc = 0;
    for (int i = 0; i < num_variables; i++)
    {
        if (!var_elim[i])
        {
            if (!(vc < new_vars))
            {
                printf("BAD ERROR 1\n");
            }
            var_ind[vc] = i;
            vc++;
        }
    }
    vc = 0;
    for (int i = 0; i < num_constraints; i++)
    {
        if (!con_elim[i])
        {
            if (!(vc < new_cons))
            {
                printf("BAD ERROR 1\n");
            }
            con_ind[vc] = i;
            vc++;
        }
    }
    for (int i = 0; i < new_vars; i++)
    {
        int olda = var_ind[i];
        g_red[i] = g_qpoases[olda];
        for (int j = 0; j < new_vars; j++)
        {
            int oldb = var_ind[j];
            H_red[i * new_vars + j] = H_qpoases[olda * num_variables + oldb];
        }
    }

    for (int con = 0; con < new_cons; con++)
    {
        for (int st = 0; st < new_vars; st++)
        {
            float cval = A_qpoases[(num_variables * con_ind[con]) + var_ind[st]];
            A_red[con * new_vars + st] = cval;
        }
    }
    for (int i = 0; i < new_cons; i++)
    {
        int old = con_ind[i];
        ub_red[i] = ub_qpoases[old];
        lb_red[i] = lb_qpoases[old];
    }

    qpOASES::QProblem problem_red(new_vars, new_cons);
    qpOASES::Options op;
    op.setToMPC(); 
    op.printLevel = qpOASES::PL_NONE;
    problem_red.setOptions(op);
    // int_t nWSR = 50000;

    int rval = problem_red.init(H_red, g_red, A_red, NULL, NULL, lb_red, ub_red, nWSR);
    //int rval = problem_red.init(_qH.data(), _qg.data(), _fMat.data(), NULL, NULL, _lb.data(), _ub.data(), nWSR);
    (void)rval;
    int rval2 = problem_red.getPrimalSolution(q_red);
    if (rval2 != qpOASES::SUCCESSFUL_RETURN)
        printf("failed to solve!\n");

    // printf("solve time: %.3f ms, size %d, %d\n", solve_timer.getMs(), new_vars, new_cons);

    vc = 0;
    for (int i = 0; i < num_variables; i++)
    {
        if (var_elim[i])
        {
            q_soln[i] = 0.0f;
        }
        else
        {
            q_soln[i] = q_red[vc];
            vc++;
        }
    }

    for(int i=0;i<12;i++)
    {
        _F(i) = q_soln[i];
    }
    // std::cout<<"f: "<<_F.transpose()<<std::endl;
}

