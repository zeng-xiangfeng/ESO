# Overview
该项目用于控制 Unitree Robotics 公司四足机器人。包含平衡控制器（Balance controller）、模型预测控制器(Model Predictive Controller)、自适应控制器（Adaptive Controller）。

# Quick Start
更详细用法请参考《四足机器人控制算法--建模、控制与实践》一书。
## Environment
我们建议用户在 Ubuntu 18.04/20.04 和 ROS 环境下运行这个项目。
## Dependencies
1. [unitree_guide](https://github.com/unitreerobotics/unitree_guide)<br>
2. [unitree_ros](https://github.com/1Liwenzhi/go1_controler/tree/unitree_ros)<br>
3. [unitree_legged_msgs](https://github.com/unitreerobotics/unitree_ros_to_real)(Note that: unitree_legged_real package should not be a part of dependencies)<br>
4. [qpoases_catkin](https://github.com/1Liwenzhi/qpoases_catkin)

Put these four packages in the src folder of a ROS workspace.

## build
打开终端并将目录切换到包含unitree_guide的ros工作区，然后运行以下命令来构建项目:
```
catkin_make
```
## run
在同一终端中，依次执行如下命令:
```
source ./devel/setup.bash
```
打开 gazebo, 运行:
```
roslaunch unitree_guide gazeboSim.launch 
```
要启动控制器，请打开另一个终端并切换到相同的目录，然后运行以下命令:
```
./devel/lib/unitree_guide/junior_ctrl
```

## 用法

按键对应状态如下：

0.balanceTest 
1.Passive
2.FixedStand
3.FreeStand
4.Trotting
6.MpcCtrl
8.StepTest
9.SwingTest

键盘控制机器人运动
---------------------------
前进/后退   W/S

左平移/右平移    A/D

左转/右转    J/L
 
空格  速度全部置零

CTRL-C  停止程序
